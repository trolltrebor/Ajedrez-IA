let board, game, timerPlayer, timerAI;
let playerTime = 300, aiTime = 300; // 5 min por jugador
let currentTurn = 'w';
let difficulty = 1;

function updateTimers() {
  document.getElementById('player-timer').textContent = formatTime(playerTime);
  document.getElementById('ai-timer').textContent = formatTime(aiTime);
}

function formatTime(sec) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function startGame() {
  game = new Chess();
  difficulty = parseInt(document.getElementById("difficulty").value);
  board.position(game.fen());
  playerTime = aiTime = 300;
  clearInterval(timerPlayer);
  clearInterval(timerAI);
  startPlayerTimer();
  updateTimers();
}

function startPlayerTimer() {
  timerPlayer = setInterval(() => {
    playerTime--;
    updateTimers();
    if (playerTime <= 0) {
      clearInterval(timerPlayer);
      alert("¡Se acabó el tiempo del jugador!");
    }
  }, 1000);
}

function startAITimer() {
  timerAI = setInterval(() => {
    aiTime--;
    updateTimers();
    if (aiTime <= 0) {
      clearInterval(timerAI);
      alert("¡Se acabó el tiempo de la IA!");
    }
  }, 1000);
}

function makeAIMove() {
  clearInterval(timerPlayer);
  startAITimer();

  setTimeout(() => {
    let moves = game.moves();
    let bestMove = moves[Math.floor(Math.random() * moves.length)];

    if (difficulty > 1) {
      bestMove = getBestMove(game, difficulty * 2);
    }

    game.move(bestMove);
    board.position(game.fen());
    clearInterval(timerAI);

    if (game.game_over()) {
      alert("Juego terminado");
      return;
    }

    startPlayerTimer();
  }, 500);
}

function getBestMove(game, depth) {
  const moves = game.moves();
  let bestEval = -Infinity;
  let bestMove = moves[0];

  for (let move of moves) {
    const copy = new Chess(game.fen());
    copy.move(move);
    const eval = minimax(copy, depth - 1, false);
    if (eval > bestEval) {
      bestEval = eval;
      bestMove = move;
    }
  }
  return bestMove;
}

function minimax(game, depth, isMaximizing) {
  if (depth === 0 || game.game_over()) return evaluateBoard(game);

  const moves = game.moves();
  if (isMaximizing) {
    let maxEval = -Infinity;
    for (let move of moves) {
      const copy = new Chess(game.fen());
      copy.move(move);
      maxEval = Math.max(maxEval, minimax(copy, depth - 1, false));
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (let move of moves) {
      const copy = new Chess(game.fen());
      copy.move(move);
      minEval = Math.min(minEval, minimax(copy, depth - 1, true));
    }
    return minEval;
  }
}

function evaluateBoard(game) {
  const values = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 1000 };
  let eval = 0;
  const board = game.board();
  for (let row of board) {
    for (let piece of row) {
      if (piece) {
        eval += (piece.color === 'w' ? 1 : -1) * values[piece.type];
      }
    }
  }
  return eval;
}

const config = {
  draggable: true,
  position: 'start',
  onDrop: (source, target) => {
    const move = game.move({ from: source, to: target, promotion: 'q' });
    if (move === null) return 'snapback';
    board.position(game.fen());
    makeAIMove();
  },
};

document.addEventListener("DOMContentLoaded", () => {
  board = Chessboard('board', config);
  game = new Chess();
  updateTimers();
});
